DOCKPROOF / ORIGINAL SYNTHETIC SCAN EXAMPLE / MIT

These fictional company names, records and illustrated damage photo were created for DockProof. The set matches the real NVIDIA + OCR browser run described in docs/model-feedback.md.

1. Extract this archive. Open My claim and add its 8 evidence files (leave README.txt and manifest.json out).
2. Assign roles: mixed PDF = Bill of lading + Delivery receipt; invoice = Invoice; warehouse inspection = Inspection / salvage; piece weights = Piece weight; rate confirmation = Booking terms; original worksheet = Original worksheet; label = Piece weight + Damage photo; JPEG = Damage photo.
3. The mixed PDF's first page has selectable text, and its second page is a raster scan. The printed page footer comes from the original before rasterization; the app records the current page and extraction method.
4. Read photo text / English on the printed PNG label. Compare the derived transcript with the original. OCR was observed reading lb. as Ib.; select the 150 lb value after inspecting its source image.
5. Run live NVIDIA extraction through a configured, credit-budgeted local server, or record source values manually in the hosted application. Review 150 lb for B4, 600 lb on the worksheet, $1,725 actual loss and the $750 class-70 reference limit/demand.
6. Approve the synthetic evidence snapshot and download the 22-file claim packet. The JPEG illustration remains an original visual attachment with zero source text.

The application keeps original SHA-256, canonical PDF/OCR text, exact source positions and reviewer choices. All eight evidence-file hashes are in manifest.json.
